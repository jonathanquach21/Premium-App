-- Run once in the SQL Editor of your own Supabase project.
-- Authenticated users can only access their own personal wallet.
begin;

create table public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  version integer not null default 0 check (version >= 0),
  constraint wallet_shape check (
    jsonb_typeof(data) = 'object'
    and data ?& array['rewards', 'entries', 'goal', 'requests']
    and jsonb_typeof(data->'rewards') = 'array'
    and jsonb_typeof(data->'entries') = 'array'
    and jsonb_typeof(data->'requests') = 'array'
    and jsonb_typeof(data->'goal') = 'number'
  )
);

alter table public.wallets enable row level security;
revoke all on table public.wallets from public, anon, authenticated;
grant select, insert, update on table public.wallets to authenticated;

create policy "Read own wallet" on public.wallets
  for select to authenticated using ((select auth.uid()) = user_id);

create policy "Create own wallet" on public.wallets
  for insert to authenticated with check ((select auth.uid()) = user_id);

create policy "Update own wallet" on public.wallets
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

commit;
