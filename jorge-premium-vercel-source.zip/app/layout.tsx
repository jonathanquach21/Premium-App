import './globals.css';
import './auth.css';
export const metadata={title:'Jorge Premium Plan',description:'Good friends. Great perks. Your Jorge Points, all in one place.',manifest:'/manifest.webmanifest',appleWebApp:{capable:true,title:'Jorge',statusBarStyle:'default'},icons:{icon:'/icon.svg',apple:'/apple-touch-icon.png'}};
export const viewport={width:'device-width',initialScale:1,themeColor:'#f6f7f9'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
