import Dashboard from './dashboard';
import { requireUser } from '../lib/auth';
import { isSupabaseConfigured } from '../lib/supabase/config';
import SetupNotice from './setup-notice';

export const dynamic = 'force-dynamic';

export default async function Page() {
  if (!isSupabaseConfigured()) return <SetupNotice />;
  await requireUser();
  return <Dashboard />;
}
