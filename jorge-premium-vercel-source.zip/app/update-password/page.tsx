import { requireUser } from '../../lib/auth';
import { isSupabaseConfigured } from '../../lib/supabase/config';
import SetupNotice from '../setup-notice';
import PasswordForm from './form';

export const dynamic = 'force-dynamic';
export default async function UpdatePassword() {
  if (!isSupabaseConfigured()) return <SetupNotice />;
  await requireUser();
  return <main className="auth-shell"><section className="auth-card"><div className="eyebrow">YOUR ACCOUNT</div><h1>A fresh start.</h1><p>Choose a new password for your membership.</p><PasswordForm /></section></main>;
}
