'use client';
import { useActionState } from 'react';
import { updatePassword, type AuthState } from '../login/actions';

export default function PasswordForm() {
  const [state, action, pending] = useActionState<AuthState, FormData>(updatePassword, {});
  return <form action={action} className="auth-form">
    <label>New password<input name="password" type="password" minLength={8} maxLength={128} autoComplete="new-password" required /></label>
    <label>Confirm new password<input name="confirmation" type="password" minLength={8} maxLength={128} autoComplete="new-password" required /></label>
    {state.error && <p role="alert" className="error">{state.error}</p>}
    {state.message && <p role="status" className="auth-message">{state.message}</p>}
    <button className="primary full" disabled={pending}>{pending ? 'Saving…' : 'Save new password'}</button>
    <a className="signout" href="/">Return to my wallet</a>
  </form>;
}
