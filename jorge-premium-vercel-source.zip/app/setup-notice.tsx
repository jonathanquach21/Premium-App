export default function SetupNotice() {
  return <main className="auth-shell"><section className="auth-card">
    <a className="brand auth-brand" href="/"><span className="brandmark">J<span>✦</span></span><div>jorge<span>PREMIUM PLAN</span></div></a>
    <div className="eyebrow">ALMOST READY</div><h1>A home for your perks.</h1>
    <p>This installation needs its database and login connection before you can sign in.</p>
    <p>The app owner can finish setup using the deployment guide included with the project.</p>
  </section></main>;
}
