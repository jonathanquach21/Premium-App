import { createClient } from '../../../lib/supabase/server';
import { isSupabaseConfigured } from '../../../lib/supabase/config';
import { walletRepository } from '../../../lib/wallet-repository';
import { readWallet, saveWalletAction, WalletActionError, WalletConflictError } from '../../../lib/wallet-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const json = (data: unknown, status = 200) => Response.json(data, { status, headers: { 'Cache-Control': 'private, no-store' } });

async function authenticatedRepository() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return null;
  return walletRepository(supabase, user.id);
}

export async function GET() {
  if (!isSupabaseConfigured()) return json({ error: 'The app owner needs to finish database setup.' }, 503);
  try {
    const repository = await authenticatedRepository();
    if (!repository) return json({ error: 'Your session expired. Please sign in again.' }, 401);
    return json(await readWallet(repository));
  } catch {
    return json({ error: 'Unable to load your wallet. Please try again.' }, 503);
  }
}

export async function POST(request: Request) {
  if (request.headers.get('origin') !== new URL(request.url).origin) return json({ error: 'Invalid request origin.' }, 403);
  if (!request.headers.get('content-type')?.includes('application/json')) return json({ error: 'Send JSON data.' }, 415);
  if (!isSupabaseConfigured()) return json({ error: 'The app owner needs to finish database setup.' }, 503);
  try {
    const repository = await authenticatedRepository();
    if (!repository) return json({ error: 'Your session expired. Please sign in again.' }, 401);
    const raw = await request.text();
    if (new TextEncoder().encode(raw).length > 3_145_728) return json({ error: 'Backup is too large. The limit is 3 MB.' }, 413);
    let action: unknown;
    try { action = JSON.parse(raw); } catch { return json({ error: 'Invalid JSON data.' }, 400); }
    return json(await saveWalletAction(repository, action));
  } catch (error) {
    if (error instanceof WalletActionError) return json({ error: error.message }, 400);
    if (error instanceof WalletConflictError) return json({ error: error.message }, 409);
    return json({ error: 'Unable to save your wallet. Your change was not confirmed; please retry.' }, 503);
  }
}
