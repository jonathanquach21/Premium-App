'use server';

import { redirect } from 'next/navigation';
import { createClient } from '../../lib/supabase/server';
import { credentials, appOrigin } from '../../lib/auth-validation';

export type AuthState = { error?: string; message?: string };

export async function authenticate(_state: AuthState, form: FormData): Promise<AuthState> {
  const mode = String(form.get('mode'));
  try {
    const { email, password } = credentials(form, mode !== 'forgot');
    const supabase = await createClient();
    if (mode === 'login') {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return { error: 'Could not sign in. Check your email and password, and confirm your email if you just registered.' };
    } else if (mode === 'signup') {
      const origin = appOrigin(process.env.APP_URL, process.env.NODE_ENV === 'production');
      const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${origin}/auth/callback` } });
      if (error) return { error: 'Could not create your account. Please try again later or contact the app owner.' };
      if (!data.session) return { message: 'Check your email to confirm your account, then come back to sign in.' };
    } else if (mode === 'forgot') {
      const origin = appOrigin(process.env.APP_URL, process.env.NODE_ENV === 'production');
      const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${origin}/auth/callback?next=/update-password` });
      if (error) return { error: 'Unable to send a reset email right now. Try again later.' };
      return { message: 'If that address has an account, a password reset email is on its way.' };
    } else return { error: 'Choose a valid sign-in option.' };
  } catch {
    return { error: 'Check your details and try again. The app owner can check the setup guide if the problem continues.' };
  }
  redirect('/');
}

export async function updatePassword(_state: AuthState, form: FormData): Promise<AuthState> {
  const password = String(form.get('password') ?? '');
  if (password.length < 8 || password.length > 128) return { error: 'Use a password between 8 and 128 characters.' };
  if (password !== String(form.get('confirmation') ?? '')) return { error: 'The passwords do not match.' };
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Your reset link expired. Request a new one from the sign-in page.' };
  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { error: 'Unable to change the password. Try another password or request a new reset link.' };
  return { message: 'Password updated. You can return to your wallet.' };
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut({ scope: 'local' });
  redirect('/login');
}
