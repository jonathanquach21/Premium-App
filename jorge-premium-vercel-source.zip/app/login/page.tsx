import { redirect } from 'next/navigation';
import AuthForm from './auth-form';
import { createClient } from '../../lib/supabase/server';
import { isSupabaseConfigured } from '../../lib/supabase/config';
import SetupNotice from '../setup-notice';

export const dynamic = 'force-dynamic';

export default async function Login({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (!isSupabaseConfigured()) return <SetupNotice />;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) redirect('/');
  const { error } = await searchParams;
  return <main className="auth-shell"><section className="auth-card">
    <a className="brand auth-brand" href="/"><span className="brandmark">J<span>✦</span></span><div>jorge<span>PREMIUM PLAN</span></div></a>
    <div className="eyebrow">YOUR PERSONAL GOOD LIFE</div>
    <h1>Your perks have a home.</h1><p>Sign in to keep your Jorge Points and rewards with you, wherever you go.</p>
    {error && <p className="error" role="alert">That account link is invalid or expired. Request a fresh link and try again.</p>}
    <AuthForm /><p className="footnote">Each account has its own private wallet.</p>
  </section></main>;
}
