'use client';

import { useActionState, useState } from 'react';
import { authenticate, type AuthState } from './actions';

export default function AuthForm() {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  return <div>
    <div className="auth-tabs">
      <button type="button" className={mode === 'login' ? 'selected' : ''} onClick={() => setMode('login')}>Sign in</button>
      <button type="button" className={mode === 'signup' ? 'selected' : ''} onClick={() => setMode('signup')}>Create account</button>
    </div>
    <ModeForm key={mode} mode={mode} />
    <button className="text-button auth-forgot" type="button" onClick={() => setMode(mode === 'forgot' ? 'login' : 'forgot')}>{mode === 'forgot' ? 'Back to sign in' : 'Forgot your password?'}</button>
  </div>;
}

function ModeForm({ mode }: { mode: 'login' | 'signup' | 'forgot' }) {
  const [state, action, pending] = useActionState<AuthState, FormData>(authenticate, {});
  return <form action={action} className="auth-form">
    <input type="hidden" name="mode" value={mode} />
    {mode === 'forgot' && <p>We’ll email you a link to reset your password.</p>}
    <label>Email address<input autoFocus type="email" name="email" autoComplete="email" maxLength={254} required placeholder="you@example.com" /></label>
    {mode !== 'forgot' && <label>Password<input type="password" name="password" autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} minLength={8} maxLength={128} required placeholder="At least 8 characters" /></label>}
    {state.error && <p className="error" role="alert">{state.error}</p>}
    {state.message && <p className="auth-message" role="status">{state.message}</p>}
    <button className="primary full" disabled={pending}>{pending ? 'One moment…' : mode === 'signup' ? 'Create my account' : mode === 'forgot' ? 'Send reset link' : 'Sign in to my perks'}</button>
  </form>;
}
