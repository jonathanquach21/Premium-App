'use client';

import { useRef, useState } from 'react';
import { parseBackup } from '../lib/backup';
import { balance, type Wallet } from '../lib/wallet';

export default function BackupImport({ disabled, onImported }: { disabled: boolean; onImported: (wallet: Wallet) => void }) {
  const [preview, setPreview] = useState<Wallet | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const key = useRef('');
  async function choose(file: File | undefined) {
    setError(''); setPreview(null);
    if (!file) return;
    try {
      if (file.size > 3_000_000) throw new Error('Choose a backup smaller than 3 MB.');
      const wallet = parseBackup(JSON.parse(await file.text()));
      key.current = crypto.randomUUID();
      setPreview(wallet);
    } catch (e) { setError(e instanceof Error ? e.message : 'Unable to read this backup.'); }
  }
  async function confirm() {
    if (!preview || busy || disabled) return;
    setBusy(true); setError('');
    try {
      const response = await fetch('/api/wallet', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'import', key: key.current, backup: { wallet: preview } }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Unable to import.');
      onImported(result.wallet); setPreview(null);
    } catch (e) { setError(e instanceof Error ? e.message : 'Unable to import.'); }
    finally { setBusy(false); }
  }
  return <div className="backup-import">
    <label>Bring your existing Jorge backup<input aria-label="Import Jorge JSON backup" type="file" accept="application/json,.json" disabled={disabled || busy} onChange={e => { void choose(e.target.files?.[0]); e.target.value = ''; }} /></label>
    <p>Import is available only in an empty real wallet. Existing records are never overwritten.</p>
    {preview && <div className="backup-summary"><b>Ready to bring your perks over?</b><p>{preview.rewards.length} rewards · {preview.entries.length} transactions · {balance(preview).toLocaleString()} JP</p><button className="primary" onClick={confirm} disabled={disabled || busy}>{busy ? 'Saving…' : 'Confirm import'}</button><button className="secondary" onClick={() => setPreview(null)} disabled={busy}>Cancel</button></div>}
    {error && <p className="error" role="alert">{error}</p>}
  </div>;
}
