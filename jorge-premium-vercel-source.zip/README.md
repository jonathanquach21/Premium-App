# Jorge Premium Plan — Vercel edition

Your Jorge Points wallet, rewards, charts and transaction history, with email/password login and cloud storage independent of ChatGPT.

This is a separate conversion of the original Cloudflare Sites app. It uses standard Next.js, Supabase Auth and Supabase Postgres. Each account has its own wallet. This version does not create a shared group wallet or give one friend control over other friends' balances.

## What you need

- A GitHub account and a Vercel account you control.
- A Supabase project you control, for Postgres and sign-in.
- An email provider connected through Supabase's custom SMTP settings before friends can receive confirmation or password reset emails. Supabase's default email service is limited to authorized project-team addresses; it is suitable for initial tests, not general sign-ups. [Supabase email setup](https://supabase.com/docs/guides/auth/auth-smtp).

## 1. Set up the database

1. Create a Supabase project at [supabase.com](https://supabase.com/dashboard).
2. In its SQL Editor, open and run `supabase/migrations/202610190001_wallets.sql` once. Keep the filename in your migration history. Do not rerun it against a populated database.
3. In Project Settings → API, copy the **Project URL** and **publishable key**. The publishable key is meant for application use and is protected by row-level security. Never substitute a `service_role` or secret key: those bypass the privacy rules.
4. The migration enables row-level security. Anonymous requests have no wallet access. Signed-in users can only read, insert and update their own row. The application never accepts a wallet owner ID from the browser.

## 2. Run locally

Use Node.js 22.13 or newer in the 22.x release line:

```sh
npm ci
cp .env.example .env.local
```

Fill in `.env.local`:

```dotenv
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
APP_URL=http://localhost:3000
```

Then run:

```sh
npm run dev
```

Open `http://localhost:3000`. Missing database configuration shows a setup notice. There is no mock login or fallback that silently saves your real data only in the browser.

## 3. Put this folder in GitHub

Create an empty private GitHub repository. Upload **the contents of this folder**, with `package.json` at the repository root. If using Git, run these from this folder and replace the example remote with your actual repository URL:

```sh
git init -b main
git add .
git commit -m "Prepare Jorge Premium Plan for Vercel"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

The included `.gitignore` excludes dependencies, local environment files, build output, logs and Vercel credentials. Commit `.env.example`, `package-lock.json`, the `supabase` migration folder and `.github/workflows/ci.yml`. Do not upload the original Sites repository or its Cloudflare configuration with this version.

The GitHub workflow installs the locked dependencies, runs tests, builds the app and checks TypeScript.

## 4. Import into Vercel

1. In [Vercel](https://vercel.com/new), choose **Add New → Project** and import the GitHub repository.
2. Use the **Next.js** framework preset. If you uploaded this folder's contents, Root Directory is the repository root. If you deliberately put it inside a larger repository, select the folder containing this edition's `package.json`.
3. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` for Production. Add them separately to Preview only if you want preview deployments to use that Supabase project. A separate Supabase project for previews avoids editing real wallets in tests.
4. Deploy. Vercel provides a stable project domain such as `https://YOUR_PROJECT.vercel.app`.
5. Set `APP_URL` in Vercel Production to that exact origin, with `https://` and no path. Redeploy after setting or changing it. The initial build works without an `APP_URL`, but account emails require it in production.

`vercel.json` selects Next.js, `npm ci` and `npm run build`. Do not set a custom Output Directory. No Cloudflare account, D1 binding, Sites header or ChatGPT login is used by this edition. [Vercel GitHub deployment](https://vercel.com/docs/git/vercel-for-github).

## 5. Finish email login configuration

In your Supabase project's Authentication settings:

1. Enable the Email provider and allow new users to sign up. Keep email confirmation enabled. Set the minimum password length to at least 8.
2. Set **Site URL** to the same production origin as `APP_URL`.
3. Add these exact allowed Redirect URLs, replacing the hostname:
   - `https://YOUR_PROJECT.vercel.app/auth/callback`
   - `https://YOUR_PROJECT.vercel.app/auth/callback?next=/update-password`
   - For local testing: `http://localhost:3000/auth/callback` and `http://localhost:3000/auth/callback?next=/update-password`.
4. Configure custom SMTP for delivery to friends. Keep SMTP credentials in Supabase's settings; this app does not need them in Vercel or GitHub.
5. Under **Email Templates → Confirm signup**, use this confirmation link. It works when the email opens on a different device from the one used to register:

```html
<h2>Confirm your Jorge account</h2>
<p><a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&amp;type=signup">Confirm email</a></p>
```

6. Under **Email Templates → Reset Password**, use:

```html
<h2>Reset your Jorge password</h2>
<p><a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&amp;type=recovery">Choose a new password</a></p>
```

The app also supports the default PKCE `/auth/callback` flow when the link opens in the original browser. Confirmation endpoints only allow the fixed wallet and password-update destinations; arbitrary redirect URLs are rejected.

For a separate staging project, configure its own Site URL, redirect URLs and `APP_URL`. When using these custom email templates with a shared Supabase project, email links point at that project's configured Site URL, including emails requested from previews.

### Verify before sharing

Create an account, confirm the email and sign in. Add points and a reward, claim it, reload, and check the balance. Sign out and test password reset. Create a second account in another browser and confirm it starts empty and cannot see the first account's wallet. Use Safari on iPhone to check the same signed-in account sees the same data.

Once this works, friends can visit your production link and create their own accounts. If Vercel shows a deployment access gate, review the project's Deployment Protection settings for Production so your intended visitors can reach the app's own sign-in page. This is separate from signing in to the Jorge app.

## 6. Bring your existing Sites wallet

1. In the original Sites app, sign in and open **Settings & backup → Download JSON backup**. Keep that backup in a safe location.
2. Create your independent account in the Vercel app and confirm its email.
3. Before adding any new points or rewards, go to **Settings & backup → Bring your existing Jorge backup**.
4. Choose the JSON file, review the displayed totals, and confirm import.

Import is allowed only when the destination wallet has no rewards or transactions. It copies your reward inventory, history and goal. Demo exports, malformed ledgers and negative balances are rejected. Imports and ordinary mutations use request IDs and conditional version updates, so retrying a request does not double a refill or import. The file limit is 3 MB.

The old Site and database are not modified. Accounts are not linked by email or ChatGPT identity. New Supabase account IDs own the imported records.

## Verification and limits

```sh
npm test
npm run build
npm run typecheck
```

Tests cover wallet arithmetic, duplicate submissions, simultaneous claims and refills, contention, backup validation, imports, input validation, and ownership policies in an embedded real Postgres engine. Production compilation and TypeScript are checked. These tests do not substitute for signing up against your own hosted Supabase project or verifying email delivery; no hosted Supabase credentials were supplied during conversion.

This is a personal, fictional-points tracker: account owners can refill their own balance. It is not an administrator-controlled loyalty currency. Wallet limits remain 500 reward definitions and 20,000 transactions; exports are JSON. The app needs internet access for cloud records. On iPhone use Safari → Share → Add to Home Screen.

Keep the GitHub repository and Supabase account recoverable, download periodic JSON exports, and configure database backups appropriate to your Supabase plan. Owning the Vercel and Supabase accounts removes the dependency on this ChatGPT account; those hosting and database accounts still need to remain active.
