import { balance, type Wallet, type Reward, type Entry } from './wallet.ts';

function fail(): never { throw new Error('This is not a valid Jorge wallet backup.'); }
function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail();
  return value as Record<string, unknown>;
}
function integer(value: unknown, min: number, max: number): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < min || value > max) fail();
  return value;
}
function text(value: unknown, max: number): string {
  if (typeof value !== 'string' || !value.trim() || value.length > max) fail();
  return value;
}
function dollars(value: unknown): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1_000_000) fail();
  return Math.round(value * 100) / 100;
}

export function parseBackup(input: unknown): Wallet {
  const backup = record(input);
  if (backup.demo === true) throw new Error('Demo data cannot be imported into your real wallet.');
  const data = record(backup.wallet);
  if (!Array.isArray(data.rewards) || data.rewards.length > 500 || !Array.isArray(data.entries) || data.entries.length > 20_000) fail();
  const rewardIds = new Set<string>(), entryIds = new Set<string>();
  const rewards: Reward[] = data.rewards.map(value => {
    const r = record(value);
    const id = text(r.id, 100);
    if (rewardIds.has(id)) fail();
    rewardIds.add(id);
    if (!['Food & drinks', 'Experiences', 'Favors', 'Other'].includes(String(r.category))) fail();
    if (typeof r.note !== 'string' || r.note.length > 240) fail();
    return { id, name: text(r.name, 120), cost: integer(r.cost, 0, 1_000_000), quantity: integer(r.quantity, 0, 999), value: dollars(r.value), category: String(r.category), note: r.note };
  });
  let runningBalance = 0;
  const entries: Entry[] = data.entries.map(value => {
    const e = record(value);
    const id = text(e.id, 100);
    if (entryIds.has(id)) fail();
    entryIds.add(id);
    if (e.kind !== 'claim' && e.kind !== 'refill') fail();
    const amount = integer(e.amount, e.kind === 'refill' ? 1 : -1_000_000, e.kind === 'refill' ? 1_000_000 : 0);
    const date = text(e.date, 40);
    if (!Number.isFinite(Date.parse(date))) fail();
    runningBalance += amount;
    if (runningBalance < 0 || !Number.isSafeInteger(runningBalance)) fail();
    return { id, date, kind: e.kind, amount, name: text(e.name, 120), value: dollars(e.value), ...(e.rewardId ? { rewardId: text(e.rewardId, 100) } : {}) };
  });
  const wallet = { rewards, entries, goal: integer(data.goal, 1, 1_000_000), requests: [] };
  if (balance(wallet) < 0) fail();
  return wallet;
}
