import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';
import { emptyWallet, type Wallet } from './wallet';
import type { WalletRepository } from './wallet-service';

// Bind the repository to the server-verified user. RLS independently enforces ownership.
export function walletRepository(supabase: SupabaseClient, userId: string): WalletRepository {
  return {
    async load() {
      const { data, error } = await supabase.from('wallets').select('data, version').eq('user_id', userId).maybeSingle();
      if (error) throw error;
      return data ? { wallet: data.data as Wallet, version: data.version as number } : null;
    },
    async create() {
      const { error } = await supabase.from('wallets').upsert({ user_id: userId, data: emptyWallet(), version: 0 }, { onConflict: 'user_id', ignoreDuplicates: true });
      if (error) throw error;
    },
    async compareAndSwap(expectedVersion, wallet) {
      // One conditional SQL UPDATE writes inventory, history and balance atomically.
      const { data, error } = await supabase.from('wallets')
        .update({ data: wallet, version: expectedVersion + 1 })
        .eq('user_id', userId).eq('version', expectedVersion)
        .select('version').maybeSingle();
      if (error) throw error;
      return Boolean(data);
    },
  };
}
