export type Reward={id:string;name:string;cost:number;quantity:number;value:number;category:string;note:string};
export type Entry={id:string;date:string;kind:'refill'|'claim';amount:number;name:string;value:number;rewardId?:string};
export type Wallet={rewards:Reward[];entries:Entry[];goal:number;requests:string[]};
export const emptyWallet=():Wallet=>({rewards:[],entries:[],goal:1000,requests:[]});
export const balance=(w:Wallet)=>w.entries.reduce((n,e)=>n+e.amount,0);
function integer(x:unknown,min:number,max=1000000){if(typeof x!=='number'||!Number.isSafeInteger(x)||x<min||x>max)throw Error(`Enter a whole number between ${min} and ${max}.`);return x;}
function text(x:unknown,max=120){if(typeof x!=='string'||!x.trim()||x.length>max)throw Error('Please enter a valid name.');return x.trim();}
export function applyAction(original:Wallet,a:any):Wallet{
 const w=structuredClone(original); const key=text(a.key,100); if(w.requests.includes(key))return w;
 if(w.entries.length>=20000)throw Error('History limit reached. Export your records before continuing.');
 if(a.type==='refill'){w.entries.push({id:crypto.randomUUID(),date:new Date().toISOString(),kind:'refill',amount:integer(a.amount,1),name:text(a.note||'Points refill'),value:0});}
 else if(a.type==='reward'){
 if(w.rewards.length>=500)throw Error('Reward limit reached.');
 const category=['Food & drinks','Experiences','Favors','Other'].includes(a.category)?a.category:'Other';
 const value=Number(a.value);if(!Number.isFinite(value)||value<0||value>1000000)throw Error('Enter a valid estimated dollar value.');
 w.rewards.push({id:crypto.randomUUID(),name:text(a.name),cost:integer(a.cost,0),quantity:integer(a.quantity,1,999),value:Math.round(value*100)/100,category,note:typeof a.note==='string'?a.note.slice(0,240):''});
 }else if(a.type==='claim'){
 const r=w.rewards.find(r=>r.id===a.id);if(!r||r.quantity<1)throw Error('This reward is no longer available.');
 if(balance(w)<r.cost)throw Error('Refill your points before claiming this reward.');
 r.quantity--;w.entries.push({id:crypto.randomUUID(),date:new Date().toISOString(),kind:'claim',amount:-r.cost,name:r.name,value:r.value,rewardId:r.id});
 }else if(a.type==='goal'){w.goal=integer(a.goal,1);}
 else throw Error('Unknown action.');
 w.requests.push(key);return w;
}
