export function credentials(form: FormData, requirePassword = true) {
  const email = String(form.get('email') ?? '').trim().toLowerCase();
  const password = String(form.get('password') ?? '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    throw new Error('Enter a valid email address.');
  }
  if (requirePassword && (password.length < 8 || password.length > 128)) {
    throw new Error('Use a password between 8 and 128 characters.');
  }
  return { email, password };
}

export function appOrigin(value: string | undefined, production: boolean) {
  if (!value && production) throw new Error('APP_URL must be configured before sending account emails.');
  const url = new URL(value || 'http://localhost:3000');
  if (url.username || url.password || url.search || url.hash || url.pathname !== '/') {
    throw new Error('APP_URL must be a plain origin, for example https://jorge.vercel.app.');
  }
  if (production && url.protocol !== 'https:') throw new Error('APP_URL must use HTTPS in production.');
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Invalid APP_URL.');
  return url.origin;
}
