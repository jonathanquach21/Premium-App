import { applyAction, emptyWallet, type Wallet } from './wallet.ts';
import { parseBackup } from './backup.ts';

export type Snapshot = { wallet: Wallet; version: number };
export type WalletRepository = {
  load(): Promise<Snapshot | null>;
  create(): Promise<void>;
  compareAndSwap(expectedVersion: number, wallet: Wallet): Promise<boolean>;
};

export class WalletActionError extends Error {}
export class WalletConflictError extends Error {}

export async function saveWalletAction(repository: WalletRepository, input: unknown): Promise<Snapshot> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new WalletActionError('Invalid wallet action.');
  const action = input as Record<string, unknown>;
  if (typeof action.key !== 'string' || !action.key.trim() || action.key.length > 100) throw new WalletActionError('Invalid request ID.');
  await repository.create();
  for (let attempt = 0; attempt < 5; attempt++) {
    const snapshot = await repository.load();
    if (!snapshot) throw new Error('Wallet could not be loaded.');
    if (snapshot.wallet.requests.includes(action.key)) return snapshot;
    let wallet: Wallet;
    try {
      if (action.type === 'import') {
        if (snapshot.wallet.entries.length || snapshot.wallet.rewards.length) throw new Error('Import is only available for an empty wallet. Export your current wallet before making changes.');
        wallet = parseBackup(action.backup);
        wallet.requests.push(action.key);
      } else wallet = applyAction(snapshot.wallet, action);
    } catch (error) {
      throw new WalletActionError(error instanceof Error ? error.message : 'Invalid wallet action.');
    }
    if (await repository.compareAndSwap(snapshot.version, wallet)) return { wallet, version: snapshot.version + 1 };
  }
  throw new WalletConflictError('Another device updated your wallet. Please try again.');
}

export async function readWallet(repository: WalletRepository): Promise<Snapshot> {
  return await repository.load() ?? { wallet: emptyWallet(), version: 0 };
}
