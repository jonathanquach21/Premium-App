import test from 'node:test';
import assert from 'node:assert/strict';
import { applyAction, emptyWallet, balance } from '../lib/wallet.ts';
import { parseBackup } from '../lib/backup.ts';
import { readWallet, saveWalletAction, WalletConflictError } from '../lib/wallet-service.ts';
import { appOrigin, credentials } from '../lib/auth-validation.ts';

const action = (type, fields = {}) => ({ type, key: crypto.randomUUID(), ...fields });
function memoryRepository(initial = null) {
  let row = initial ? { wallet: structuredClone(initial), version: 0 } : null;
  return {
    async load() { return structuredClone(row); },
    async create() { row ??= { wallet: emptyWallet(), version: 0 }; },
    async compareAndSwap(expectedVersion, wallet) {
      if (row.version !== expectedVersion) return false;
      row = { wallet: structuredClone(wallet), version: expectedVersion + 1 };
      return true;
    },
  };
}

test('missing wallet reads empty without writing', async () => {
  const repo = memoryRepository();
  assert.deepEqual(await readWallet(repo), { wallet: emptyWallet(), version: 0 });
  assert.equal(await repo.load(), null);
});

test('simultaneous identical refill requests add points only once', async () => {
  const repo = memoryRepository();
  const refill = action('refill', { amount: 500 });
  await Promise.all([saveWalletAction(repo, refill), saveWalletAction(repo, refill)]);
  const { wallet, version } = await repo.load();
  assert.equal(balance(wallet), 500);
  assert.equal(wallet.entries.length, 1);
  assert.equal(version, 1);
});

test('two different simultaneous claims cannot overspend or consume inventory twice', async () => {
  let wallet = applyAction(emptyWallet(), action('refill', { amount: 250 }));
  wallet = applyAction(wallet, action('reward', { name: 'Dinner', cost: 250, quantity: 1, value: 35 }));
  const repo = memoryRepository(wallet);
  const results = await Promise.allSettled(Array.from({ length: 2 }, () => saveWalletAction(repo, action('claim', { id: wallet.rewards[0].id }))));
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 1);
  const saved = (await repo.load()).wallet;
  assert.equal(balance(saved), 0);
  assert.equal(saved.rewards[0].quantity, 0);
  assert.equal(saved.entries.filter(e => e.kind === 'claim').length, 1);
});

test('two simultaneous refills both survive a version conflict', async () => {
  const repo = memoryRepository();
  await Promise.all([saveWalletAction(repo, action('refill', { amount: 200 })), saveWalletAction(repo, action('refill', { amount: 300 }))]);
  assert.equal(balance((await repo.load()).wallet), 500);
});

test('persistent contention returns conflict instead of pretending to save', async () => {
  const repo = memoryRepository();
  repo.compareAndSwap = async () => false;
  await assert.rejects(saveWalletAction(repo, action('refill', { amount: 100 })), WalletConflictError);
  assert.equal(balance((await repo.load()).wallet), 0);
});

test('Sites export imports once into an empty wallet and preserves records', async () => {
  const wallet = applyAction(emptyWallet(), action('refill', { amount: 600, note: 'Original history' }));
  const repo = memoryRepository();
  const importAction = action('import', { backup: { exportedAt: new Date().toISOString(), demo: false, wallet } });
  const first = await saveWalletAction(repo, importAction);
  const replay = await saveWalletAction(repo, importAction);
  assert.deepEqual(replay, first);
  assert.equal(balance(first.wallet), 600);
  assert.deepEqual(first.wallet.entries, wallet.entries);
  await assert.rejects(saveWalletAction(repo, action('import', { backup: { wallet } })), /empty wallet/);
});

test('malformed and demo backups cannot overwrite a real wallet', () => {
  assert.throws(() => parseBackup({ demo: true, wallet: emptyWallet() }), /Demo data/);
  for (const data of [null, [], {}, { wallet: { rewards: [], entries: [] } }]) assert.throws(() => parseBackup(data));
  const wallet = applyAction(emptyWallet(), action('refill', { amount: 100 }));
  const negative = structuredClone(wallet);
  negative.entries[0].amount = -1;
  assert.throws(() => parseBackup({ wallet: negative }));
  const duplicates = structuredClone(wallet);
  duplicates.entries.push(duplicates.entries[0]);
  assert.throws(() => parseBackup({ wallet: duplicates }));
  const invalid = structuredClone(wallet);
  invalid.entries[0].date = 'not a date';
  assert.throws(() => parseBackup({ wallet: invalid }));
});

test('invalid actions do not create transactions', async () => {
  const repo = memoryRepository();
  for (const value of [null, [], 'refill', {}, { type: 'refill', key: '' }]) await assert.rejects(saveWalletAction(repo, value));
  assert.equal(await repo.load(), null);
});

test('account email origin must be explicit HTTPS in production', () => {
  assert.equal(appOrigin(undefined, false), 'http://localhost:3000');
  assert.equal(appOrigin('https://jorge.vercel.app', true), 'https://jorge.vercel.app');
  for (const url of [undefined, 'http://example.com', 'https://evil:password@example.com', 'https://example.com/path', 'https://example.com?next=evil', 'javascript:alert(1)']) assert.throws(() => appOrigin(url, true));
});

test('credentials reject malformed emails and short passwords', () => {
  const form = new FormData();
  form.set('email', 'PERSON@example.com'); form.set('password', 'a-long-password');
  assert.deepEqual(credentials(form), { email: 'person@example.com', password: 'a-long-password' });
  form.set('password', 'short'); assert.throws(() => credentials(form));
  form.set('email', 'not-an-email'); assert.throws(() => credentials(form, false));
});
