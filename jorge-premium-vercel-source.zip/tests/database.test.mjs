import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
import { emptyWallet } from '../lib/wallet.ts';

test('Postgres migration enforces ownership and atomic conditional writes', async () => {
  const db = new PGlite();
  try {
    // Emulate Supabase's pre-existing auth schema and API roles in real Postgres.
    await db.exec(`
      create role anon nologin;
      create role authenticated nologin;
      create schema auth;
      create table auth.users (id uuid primary key);
      create function auth.uid() returns uuid language sql stable as
        $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
      grant usage on schema auth, public to anon, authenticated;
    `);
    await db.exec(await readFile(new URL('../supabase/migrations/202610190001_wallets.sql', import.meta.url), 'utf8'));
    const alice = '00000000-0000-4000-8000-000000000001';
    const bob = '00000000-0000-4000-8000-000000000002';
    await db.query('insert into auth.users(id) values ($1),($2)', [alice, bob]);
    await db.exec('set role authenticated');
    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [alice]);
    await db.query('insert into public.wallets(user_id,data) values ($1,$2)', [alice, JSON.stringify(emptyWallet())]);
    await assert.rejects(db.query('insert into public.wallets(user_id,data) values ($1,$2)', [bob, JSON.stringify(emptyWallet())]), /row-level security/);

    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [bob]);
    assert.equal((await db.query('select * from public.wallets')).rows.length, 0);
    assert.equal((await db.query('update public.wallets set version=99 where user_id=$1 returning user_id', [alice])).rows.length, 0);
    await db.query('insert into public.wallets(user_id,data) values ($1,$2)', [bob, JSON.stringify(emptyWallet())]);
    assert.equal((await db.query('select * from public.wallets')).rows.length, 1);

    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [alice]);
    await assert.rejects(db.query('update public.wallets set user_id=$1 where user_id=$2', [bob, alice]));
    const writes = await Promise.all([
      db.query('update public.wallets set version=1 where user_id=$1 and version=0 returning version', [alice]),
      db.query('update public.wallets set version=1 where user_id=$1 and version=0 returning version', [alice]),
    ]);
    assert.equal(writes.reduce((n, r) => n + r.rows.length, 0), 1);
    await assert.rejects(db.query('delete from public.wallets where user_id=$1', [alice]), /permission denied/);

    await db.exec('reset role; set role anon');
    await assert.rejects(db.query('select * from public.wallets'), /permission denied/);
  } finally { await db.close(); }
});
