import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyWallet,applyAction,balance} from '../lib/wallet.ts';
const act=(w,a)=>applyAction(w,{key:crypto.randomUUID(),...a});
test('refill, add reward, claim and preserve history',()=>{let w=act(emptyWallet(),{type:'refill',amount:500});w=act(w,{type:'reward',name:'Dinner',cost:250,quantity:1,value:35});w=act(w,{type:'claim',id:w.rewards[0].id});assert.equal(balance(w),250);assert.equal(w.rewards[0].quantity,0);assert.equal(w.entries.length,2);assert.equal(w.entries[1].value,35);assert.throws(()=>act(w,{type:'claim',id:w.rewards[0].id}),/no longer available/);});
test('reject overspend without mutating wallet',()=>{const w=act(emptyWallet(),{type:'reward',name:'Dinner',cost:250,quantity:1,value:35});assert.throws(()=>act(w,{type:'claim',id:w.rewards[0].id}),/Refill/);assert.equal(w.rewards[0].quantity,1);assert.equal(w.entries.length,0)});
test('replayed request is idempotent',()=>{const a={type:'refill',amount:100,key:'same-key'};const w=applyAction(emptyWallet(),a);assert.equal(balance(applyAction(w,a)),100)});
test('invalid amounts and values never enter ledger',()=>{for(const amount of [-1,0,NaN,Infinity,1.5,1000001,'100'])assert.throws(()=>act(emptyWallet(),{type:'refill',amount}));assert.throws(()=>act(emptyWallet(),{type:'reward',name:'Dinner',cost:10,quantity:1,value:-2}));});
test('zero-point rewards and goal changes preserve balance',()=>{let w=act(emptyWallet(),{type:'reward',name:'Free hug',cost:0,quantity:1,value:0});w=act(w,{type:'claim',id:w.rewards[0].id});w=act(w,{type:'goal',goal:500});assert.equal(balance(w),0);assert.equal(w.goal,500);assert.equal(w.entries.length,1)});
